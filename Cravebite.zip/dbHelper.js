// dbHelper.js - SQLite Query Helpers

window.dbHelper = {
    async waitForDB() {
        if (typeof dbReady !== 'undefined') {
            await dbReady;
        }
        if (!db) {
            throw new Error("Database not initialized");
        }
    },

    async insertUser(fullName, email, password, phone) {
        await this.waitForDB();
        try {
            db.run(
                "INSERT INTO users (full_name, email, password_hash, phone) VALUES (?, ?, ?, ?)",
                [fullName, email, password, phone]
            );
            saveDB();
            const res = db.exec("SELECT last_insert_rowid() AS id");
            return res[0].values[0][0];
        } catch (e) {
            console.error("Error inserting user:", e);
            throw e;
        }
    },

    async getUserByEmail(email) {
        await this.waitForDB();
        const res = db.exec("SELECT * FROM users WHERE email = ?", [email]);
        if (res.length > 0) {
            const columns = res[0].columns;
            const values = res[0].values[0];
            const user = {};
            columns.forEach((col, index) => {
                user[col] = values[index];
            });
            return user;
        }
        return null;
    },

    async saveAddress(userId, label, fullAddress, city, state, pincode, landmark, isDefault = 0) {
        await this.waitForDB();
        try {
            if (isDefault) {
                db.run("UPDATE addresses SET is_default = 0 WHERE user_id = ?", [userId]);
            }
            db.run(
                "INSERT INTO addresses (user_id, label, full_address, city, state, pincode, landmark, is_default) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                [userId, label, fullAddress, city, state, pincode, landmark, isDefault]
            );
            saveDB();
            const res = db.exec("SELECT last_insert_rowid() AS id");
            return res[0].values[0][0];
        } catch (e) {
            console.error("Error saving address:", e);
            throw e;
        }
    },

    async getUserAddresses(userId) {
        await this.waitForDB();
        const res = db.exec("SELECT * FROM addresses WHERE user_id = ?", [userId]);
        if (res.length > 0) {
            return res[0].values.map(row => {
                const addr = {};
                res[0].columns.forEach((col, idx) => addr[col] = row[idx]);
                return addr;
            });
        }
        return [];
    },

    async getAllMenuItems() {
        await this.waitForDB();
        const res = db.exec("SELECT * FROM menu_items");
        if (res.length > 0) {
            return res[0].values.map(row => {
                const item = {};
                res[0].columns.forEach((col, idx) => {
                    // map DB names back to some JS standard camelCase
                    if (col === 'is_veg') item.isVeg = row[idx] === 1;
                    else if (col === 'description') item.desc = row[idx];
                    else item[col] = row[idx];
                });
                return item;
            });
        }
        return [];
    },
    
    async getMenuItem(id) {
        await this.waitForDB();
        const res = db.exec("SELECT * FROM menu_items WHERE id = ?", [id]);
        if (res.length > 0) {
            const item = {};
            res[0].columns.forEach((col, idx) => {
                if (col === 'is_veg') item.isVeg = res[0].values[0][idx] === 1;
                else if (col === 'description') item.desc = res[0].values[0][idx];
                else item[col] = res[0].values[0][idx];
            });
            return item;
        }
        return null;
    },

    async insertOrder(userId, addressId, subtotal, gst, deliveryFee, totalAmount, paymentMethod) {
        await this.waitForDB();
        try {
            db.run(
                "INSERT INTO orders (user_id, address_id, payment_method, payment_status, subtotal, gst, delivery_fee, total_amount) VALUES (?, ?, ?, 'Paid', ?, ?, ?, ?)",
                [userId, addressId, paymentMethod, subtotal, gst, deliveryFee, totalAmount]
            );
            saveDB();
            const res = db.exec("SELECT last_insert_rowid() AS id");
            return res[0].values[0][0];
        } catch (e) {
            console.error("Error inserting order:", e);
            throw e;
        }
    },

    async insertOrderItems(orderId, itemsArray) {
        await this.waitForDB();
        try {
            db.run("BEGIN TRANSACTION;");
            const stmt = db.prepare("INSERT INTO order_items (order_id, menu_item_id, quantity, price_at_order) VALUES (?, ?, ?, ?)");
            itemsArray.forEach(item => {
                stmt.run([orderId, item.menu_item_id, item.quantity, item.price_at_order]);
            });
            stmt.free();
            db.run("COMMIT;");
            saveDB();
        } catch (e) {
            db.run("ROLLBACK;");
            console.error("Error inserting order items:", e);
            throw e;
        }
    },

    async insertDeliveryInfo(orderId, driverName, driverPhone, vehicle_number, status, lat = 0, lng = 0) {
        await this.waitForDB();
        try {
            db.run(
                "INSERT INTO delivery_info (order_id, driver_name, driver_phone, vehicle_number, current_status, live_lat, live_lng) VALUES (?, ?, ?, ?, ?, ?, ?)",
                [orderId, driverName, driverPhone, vehicle_number, status, lat, lng]
            );
            saveDB();
        } catch (e) {
            console.error("Error inserting delivery info:", e);
            throw e;
        }
    },

    async getOrdersByUser(userId) {
        await this.waitForDB();
        const res = db.exec("SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC", [userId]);
        if (res.length > 0) {
            return res[0].values.map(row => {
                const order = {};
                res[0].columns.forEach((col, idx) => order[col] = row[idx]);
                return order;
            });
        }
        return [];
    },

    async saveCartItem(userId, menuItemId, quantity) {
        await this.waitForDB();
        try {
            // Check if exists
            const exists = db.exec("SELECT quantity FROM cart WHERE user_id = ? AND menu_item_id = ?", [userId, menuItemId]);
            if (exists.length > 0) {
                if (quantity <= 0) {
                    db.run("DELETE FROM cart WHERE user_id = ? AND menu_item_id = ?", [userId, menuItemId]);
                } else {
                    db.run("UPDATE cart SET quantity = ? WHERE user_id = ? AND menu_item_id = ?", [quantity, userId, menuItemId]);
                }
            } else if (quantity > 0) {
                db.run("INSERT INTO cart (user_id, menu_item_id, quantity) VALUES (?, ?, ?)", [userId, menuItemId, quantity]);
            }
            saveDB();
        } catch (e) {
            console.error("Error saving cart item:", e);
            throw e;
        }
    },

    async getCartByUser(userId) {
        await this.waitForDB();
        // Join with menu_items to get price, desc, image, name etc.
        const query = `
            SELECT c.menu_item_id, c.quantity, m.name, m.price, m.image, m.description as desc, m.is_veg
            FROM cart c
            JOIN menu_items m ON c.menu_item_id = m.id
            WHERE c.user_id = ?
        `;
        const res = db.exec(query, [userId]);
        if (res.length > 0) {
            return res[0].values.map(row => {
                const item = {};
                res[0].columns.forEach((col, idx) => {
                    if (col === 'menu_item_id') item.id = row[idx];
                    else if (col === 'is_veg') item.isVeg = row[idx] === 1;
                    else item[col] = row[idx];
                });
                return item;
            });
        }
        return [];
    },

    async clearCart(userId) {
        await this.waitForDB();
        try {
            db.run("DELETE FROM cart WHERE user_id = ?", [userId]);
            saveDB();
        } catch (e) {
            console.error("Error clearing cart:", e);
            throw e;
        }
    }
};
