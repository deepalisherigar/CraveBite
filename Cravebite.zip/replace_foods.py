import json
import urllib.request
import re

meals = []
for char in ['c', 's', 'b', 'p', 'm', 'a']:
    try:
        url = f"https://www.themealdb.com/api/json/v1/1/search.php?f={char}"
        req = urllib.request.urlopen(url)
        data = json.loads(req.read())
        if data['meals']:
            for m in data['meals']:
                meals.append({
                    'name': m['strMeal'],
                    'image': m['strMealThumb'],
                    'category': m['strCategory'],
                    'isVeg': m['strCategory'] in ['Vegetarian', 'Vegan', 'Dessert']
                })
    except Exception as e:
        print("Error fetching from mealdb:", e)

# Filter duplicates
unique_meals = []
seen = set()
for m in meals:
    if m['name'] not in seen:
        seen.add(m['name'])
        unique_meals.append(m)

print(f"Fetched {len(unique_meals)} unique meals.")

with open('data.js', 'r', encoding='utf-8') as f:
    content = f.read()

lines = content.split('\n')
new_lines = []
meal_idx = 0

for line in lines:
    if 'placehold.co' in line and meal_idx < len(unique_meals):
        meal = unique_meals[meal_idx]
        meal_idx += 1
        
        line = re.sub(r'name:\s*"[^"]+"', f'name: "{meal["name"]}"', line)
        line = re.sub(r'image:\s*"[^"]+"', f'image: "{meal["image"]}/preview"', line)
        
        is_veg_str = "true" if meal["isVeg"] else "false"
        line = re.sub(r'isVeg:\s*(true|false)', f'isVeg: {is_veg_str}', line)
        
        desc = f"Delicious and authentic {meal['name']} prepared with fresh ingredients."
        line = re.sub(r'desc:\s*"[^"]+"', f'desc: "{desc}"', line)
        print(f"Replaced placholder with: {meal['name']}")
        
    new_lines.append(line)

with open('data.js', 'w', encoding='utf-8') as f:
    f.write('\n'.join(new_lines))

print(f"Total replaced: {meal_idx}")
