// db.js - SQLite Initialization and persistence

let db = null;

async function initDB() {
    const config = {
        locateFile: filename => `https://cdnjs.cloudflare.com/ajax/libs/sql.js/1.10.2/${filename}`
    };

    try {
        const SQL = await initSqlJs(config);
        
        // Try to load from localStorage
        const savedDb = localStorage.getItem('cravebite_db');
        if (savedDb) {
            // Load existing db
            const uInt8Array = new Uint8Array(atob(savedDb).split('').map(c => c.charCodeAt(0)));
            db = new SQL.Database(uInt8Array);
            console.log("Database loaded from localStorage.");
        } else {
            // Initialize new db
            db = new SQL.Database();
            console.log("Creating new Database...");
            createTables();
            seedData();
            saveDB();
        }
        
        // Ensure foreign keys are enabled
        db.run("PRAGMA foreign_keys = ON;");
    } catch (e) {
        console.error("Error initializing SQLite DB:", e);
    }
}

function createTables() {
    const createQuery = `
        CREATE TABLE users (
            user_id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT,
            email TEXT UNIQUE,
            password_hash TEXT,
            phone TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            is_active INTEGER DEFAULT 1
        );

        CREATE TABLE addresses (
            address_id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            label TEXT,
            full_address TEXT,
            city TEXT,
            state TEXT,
            pincode TEXT,
            landmark TEXT,
            is_default INTEGER DEFAULT 0,
            FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
        );

        CREATE TABLE menu_items (
            id INTEGER PRIMARY KEY,
            name TEXT,
            category TEXT,
            price REAL,
            is_veg INTEGER,
            spicy INTEGER,
            rating REAL,
            image TEXT,
            description TEXT,
            is_available INTEGER DEFAULT 1,
            preparation_time INTEGER DEFAULT 15,
            calories INTEGER DEFAULT 0
        );

        CREATE TABLE orders (
            order_id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            address_id INTEGER,
            status TEXT DEFAULT 'Placed',
            payment_method TEXT,
            payment_status TEXT DEFAULT 'Pending',
            subtotal REAL,
            gst REAL,
            delivery_fee REAL,
            total_amount REAL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            estimated_delivery DATETIME,
            FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
            FOREIGN KEY (address_id) REFERENCES addresses(address_id) ON DELETE SET NULL
        );

        CREATE TABLE order_items (
            order_item_id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER,
            menu_item_id INTEGER,
            quantity INTEGER,
            price_at_order REAL,
            FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
            FOREIGN KEY (menu_item_id) REFERENCES menu_items(id) ON DELETE CASCADE
        );

        CREATE TABLE delivery_info (
            delivery_id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER UNIQUE,
            driver_name TEXT,
            driver_phone TEXT,
            vehicle_number TEXT,
            current_status TEXT,
            estimated_arrival DATETIME,
            live_lat REAL,
            live_lng REAL,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE
        );

        CREATE TABLE reviews (
            review_id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            menu_item_id INTEGER,
            order_id INTEGER,
            rating INTEGER CHECK(rating BETWEEN 1 AND 5),
            comment TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
            FOREIGN KEY (menu_item_id) REFERENCES menu_items(id) ON DELETE CASCADE,
            FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE
        );

        CREATE TABLE cart (
            cart_id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            menu_item_id INTEGER,
            quantity INTEGER DEFAULT 1,
            added_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
            FOREIGN KEY (menu_item_id) REFERENCES menu_items(id) ON DELETE CASCADE
        );
    `;
    db.run(createQuery);
}

function seedData() {
    if (typeof menuItems !== 'undefined' && menuItems.length > 0) {
        db.run("BEGIN TRANSACTION;");
        const stmt = db.prepare(`
            INSERT INTO menu_items (id, name, category, price, is_veg, spicy, rating, image, description)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);
        
        menuItems.forEach(item => {
            stmt.run([
                item.id,
                item.name,
                item.category,
                item.price,
                item.isVeg ? 1 : 0,
                item.spicy ? 1 : 0,
                item.rating,
                item.image,
                item.desc
            ]);
        });
        stmt.free();
        db.run("COMMIT;");
        console.log("Seeded database with menu items.");
    }
}

// Global function to save DB over stringified binary
function saveDB() {
    if (db) {
        const data = db.export();
        // Convert to base64
        const base64 = btoa(String.fromCharCode.apply(null, data));
        localStorage.setItem('cravebite_db', base64);
    }
}

// Initializing the process immediately, wrap dependencies logically. 
// Other scripts should wait or rely on await dbReady;
const dbReady = initDB();
