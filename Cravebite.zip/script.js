// State variables
let cart = [];
let allDbItems = [];
let filteredItems = [];
const GST_RATE = 0.05;
const DELIVERY_FEE = 40;
let currentUserId = sessionStorage.getItem('user_id');
let selectedAddressId = null;

// DOM Elements
const menuGrid = document.getElementById('menuGrid');
const emptyState = document.getElementById('emptyState');
const searchInput = document.getElementById('searchInput');
const vegToggle = document.getElementById('vegToggle');
const categoryPills = document.querySelectorAll('.pill');

// Cart DOM
const cartTrigger = document.getElementById('cartTrigger');
const cartOverlay = document.getElementById('cartOverlay');
const cartSidebar = document.getElementById('cartSidebar');
const closeCart = document.getElementById('closeCart');
const cartItemsContainer = document.getElementById('cartItems');
const cartBadge = document.getElementById('cartBadge');
const subtotalDisplay = document.getElementById('subtotalDisplay');
const gstDisplay = document.getElementById('gstDisplay');
const totalDisplay = document.getElementById('totalDisplay');
const checkoutBtn = document.getElementById('checkoutBtn');

// Modals DOM
const paymentModal = document.getElementById('paymentModal');
const closePaymentModal = document.getElementById('closePaymentModal');
const payTabs = document.querySelectorAll('.pay-tab');
const payForms = document.querySelectorAll('.pay-form');
const finalAmtSpans = document.querySelectorAll('.final-amt');

const successModal = document.getElementById('successModal');
const backToMenuBtn = document.getElementById('backToMenuBtn');
const orderIdDisplay = document.getElementById('orderIdDisplay');
const toastContainer = document.getElementById('toastContainer');

/* --- Initialization --- */
document.addEventListener('DOMContentLoaded', async () => {
    try {
        await window.dbHelper.waitForDB();
        allDbItems = await window.dbHelper.getAllMenuItems();
        filteredItems = [...allDbItems];
        
        if (currentUserId) {
            cart = await window.dbHelper.getCartByUser(currentUserId);
            renderOrders();
            document.getElementById('navOrdersLink').style.display = 'inline-block';
        }
        
        renderMenu(filteredItems);
        updateCartState();
        setupEventListeners();

        // Check Login State
        const loginBtn = document.querySelector('.nav-login-btn');
        if (localStorage.getItem('isLoggedIn') === 'true') {
            if (loginBtn) {
                loginBtn.innerHTML = "<i class='bx bx-user'></i> Logout";
                loginBtn.href = "#";
                loginBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    sessionStorage.removeItem('user_id');
                    localStorage.removeItem('isLoggedIn');
                    window.location.reload();
                });
            }
        }
    } catch (e) {
        console.error("Initialization error:", e);
        showToast("Error connecting to database");
    }
});

/* --- Event Listeners Setup --- */
function setupEventListeners() {
    // Search
    searchInput.addEventListener('input', handleFilters);
    
    // Veg Toggle
    vegToggle.addEventListener('change', handleFilters);

    // Categories
    categoryPills.forEach(pill => {
        pill.addEventListener('click', (e) => {
            categoryPills.forEach(p => p.classList.remove('active'));
            e.target.classList.add('active');
            handleFilters();
        });
    });

    // Menu Grid Delegation
    menuGrid.addEventListener('click', (e) => {
        const addBtn = e.target.closest('.add-btn');
        if (addBtn) {
            addToCart(parseInt(addBtn.dataset.id));
            return;
        }
        
        const qtyBtn = e.target.closest('.qty-btn');
        if (qtyBtn) {
            const id = parseInt(qtyBtn.dataset.id);
            const change = qtyBtn.classList.contains('qty-inc') ? 1 : -1;
            updateQuantity(id, change);
        }
    });

    // Cart Items Delegation
    cartItemsContainer.addEventListener('click', (e) => {
        const removeBtn = e.target.closest('.remove-btn');
        if (removeBtn) {
            removeFromCart(parseInt(removeBtn.dataset.id));
            return;
        }

        const qtyBtn = e.target.closest('.qty-btn');
        if (qtyBtn) {
            const id = parseInt(qtyBtn.dataset.id);
            const change = qtyBtn.classList.contains('qty-inc') ? 1 : -1;
            updateQuantity(id, change);
        }
    });

    // Cart Sidebar Toggles
    cartTrigger.addEventListener('click', () => {
        cartOverlay.classList.add('active');
        cartSidebar.classList.add('active');
    });
    closeCart.addEventListener('click', () => {
        cartOverlay.classList.remove('active');
        cartSidebar.classList.remove('active');
    });
    cartOverlay.addEventListener('click', () => closeCart.click());

    // Payment Modal Toggles
    checkoutBtn.addEventListener('click', () => {
        if(cart.length === 0) return;
        closeCart.click();
        
        // Update total in payment forms
        const total = calculateTotals().total;
        finalAmtSpans.forEach(span => span.textContent = `₹${total}`);
        
        // Render Address list
        renderAddresses();
        
        paymentModal.classList.add('active');
    });

    closePaymentModal.addEventListener('click', () => paymentModal.classList.remove('active'));

    // Payment Tabs
    payTabs.forEach(tab => {
        tab.addEventListener('click', (e) => {
            payTabs.forEach(t => t.classList.remove('active'));
            payForms.forEach(f => f.classList.remove('active'));
            
            e.target.closest('.pay-tab').classList.add('active');
            const targetForm = e.target.closest('.pay-tab').dataset.method + 'Form';
            document.getElementById(targetForm).classList.add('active');
        });
    });

    // Payment Form Submissions
    payForms.forEach(form => {
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            processPayment();
        });
    });

    // Success back button
    backToMenuBtn.addEventListener('click', () => {
        successModal.classList.remove('active');
        cart = [];
        updateCartState();
        renderMenu(filteredItems); // refresh to reset add buttons
        renderOrders(); // Refresh orders list
        window.scrollTo({ top: document.getElementById('menu').offsetTop, behavior: 'smooth' });
    });

    // Add new address UI toggle
    document.getElementById('addNewAddressBtn').addEventListener('click', () => {
        document.getElementById('newAddressForm').style.display = 'block';
        document.getElementById('addNewAddressBtn').style.display = 'none';
    });

    // Cancel address btn
    document.getElementById('cancelAddressBtn').addEventListener('click', () => {
        document.getElementById('newAddressForm').style.display = 'none';
        document.getElementById('addNewAddressBtn').style.display = 'block';
    });

    // Save address flow
    document.getElementById('saveAddressBtn').addEventListener('click', async () => {
        const label = document.getElementById('newAddrLabel').value;
        const full = document.getElementById('newAddrFull').value;
        const city = document.getElementById('newAddrCity').value;
        const state = document.getElementById('newAddrState').value;
        const pin = document.getElementById('newAddrPin').value;
        const landmark = document.getElementById('newAddrLandmark').value;
        
        if (!label || !full || !city || !state || !pin) {
            alert('Please fill required fields.');
            return;
        }

        try {
            await window.dbHelper.saveAddress(currentUserId, label, full, city, state, pin, landmark, 0);
            document.getElementById('newAddressForm').style.display = 'none';
            document.getElementById('addNewAddressBtn').style.display = 'block';
            renderAddresses();
            showToast("Address saved!");
        } catch (e) {
            console.error(e);
            alert("Error saving address");
        }
    });

    // Address selection listener via delegation
    document.getElementById('addressList').addEventListener('change', (e) => {
        if (e.target.name === 'checkoutAddress') {
            selectedAddressId = e.target.value;
        }
    });
}

/* --- Filtering Logic --- */
function handleFilters() {
    const searchTerm = searchInput.value.toLowerCase();
    const isVegOnly = vegToggle.checked;
    const activeCategory = document.querySelector('.pill.active').dataset.category;

    filteredItems = allDbItems.filter(item => {
        // Search Match
        const matchSearch = item.name.toLowerCase().includes(searchTerm) || item.desc.toLowerCase().includes(searchTerm);
        // Veg Match
        const matchVeg = isVegOnly ? item.isVeg === true : true;
        // Category Match
        const matchCategory = activeCategory === 'All' ? true : item.category === activeCategory;

        return matchSearch && matchVeg && matchCategory;
    });

    renderMenu(filteredItems);
}

/* --- Render Menu --- */
function renderMenu(items) {
    menuGrid.innerHTML = '';
    
    if (items.length === 0) {
        emptyState.style.display = 'block';
        return;
    }
    
    emptyState.style.display = 'none';

    items.forEach(item => {
        const inCart = cart.find(c => c.id === item.id);
        
        // tags
        let tagsHtml = '';
        if (item.isVeg) {
            tagsHtml += `<span class="tag tag-veg"><i class='bx bx-radio-circle-marked'></i> Veg</span>`;
        } else {
            tagsHtml += `<span class="tag tag-nonveg"><i class='bx bx-radio-circle-marked'></i> Non-Veg</span>`;
        }
        if (item.spicy) {
            tagsHtml += `<span class="tag tag-spicy"><i class='bx bxs-flame'></i> Spicy</span>`;
        }

        const card = document.createElement('div');
        card.className = 'food-card';
        card.innerHTML = `
            <div style="position: relative;">
                <img src="${item.image}" alt="${item.name}" class="card-img" loading="lazy">
                <div class="card-tags">${tagsHtml}</div>
            </div>
            <div class="card-content">
                <div class="card-header">
                    <div class="food-name">${item.name}</div>
                    <div class="star-rating">${item.rating} <i class='bx bxs-star'></i></div>
                </div>
                <p class="food-desc">${item.desc}</p>
                <div class="card-footer">
                    <div class="food-price">₹${item.price}</div>
                    <div class="action-area" id="action-${item.id}">
                        ${inCart ? getQtyControlsHtml(item.id, inCart.quantity) : `<button class="add-btn" data-id="${item.id}">Add to Cart</button>`}
                    </div>
                </div>
            </div>
        `;
        menuGrid.appendChild(card);
    });
}

/* --- Cart Logic --- */
async function addToCart(id) {
    if (!currentUserId || localStorage.getItem("isLoggedIn") !== "true") {
        showToast("Please login to place an order! Redirecting...");
        setTimeout(() => window.location.href = "login.html", 1500);
        return;
    }

    const item = allDbItems.find(i => i.id === id);
    if (!item) return;

    cart.push({ ...item, quantity: 1 });
    showToast(`${item.name} added to cart!`);
    updateCartState();
    refreshItemCard(id);
    
    try {
        await window.dbHelper.saveCartItem(currentUserId, id, 1);
    } catch(e) { console.error(e); }
}

async function updateQuantity(id, change) {
    const itemIndex = cart.findIndex(c => c.id === id);
    if (itemIndex > -1) {
        cart[itemIndex].quantity += change;
        const newQty = cart[itemIndex].quantity;
        if (newQty <= 0) {
            cart.splice(itemIndex, 1);
        }
        updateCartState();
        refreshItemCard(id);
        try {
            await window.dbHelper.saveCartItem(currentUserId, id, newQty);
        } catch(e) {}
    }
}

async function removeFromCart(id) {
    const itemIndex = cart.findIndex(c => c.id === id);
    if (itemIndex > -1) {
        cart.splice(itemIndex, 1);
        updateCartState();
        refreshItemCard(id);
        try {
            await window.dbHelper.saveCartItem(currentUserId, id, 0);
        } catch(e) {}
    }
}

function getQtyControlsHtml(id, qty) {
    return `
        <div class="qty-controls">
            <button class="qty-btn qty-dec" data-id="${id}">-</button>
            <span class="qty-val">${qty}</span>
            <button class="qty-btn qty-inc" data-id="${id}">+</button>
        </div>
    `;
}

function refreshItemCard(id) {
    // Only refresh the specific action area in the menu to avoid re-rendering entire grid
    const actionArea = document.getElementById(`action-${id}`);
    if (actionArea) {
        const inCart = cart.find(c => c.id === id);
        if (inCart) {
            actionArea.innerHTML = getQtyControlsHtml(id, inCart.quantity);
        } else {
            actionArea.innerHTML = `<button class="add-btn" data-id="${id}">Add to Cart</button>`;
        }
    }
}

function updateCartState() {
    // Badge
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    cartBadge.textContent = totalItems;
    
    // Animate badge
    cartBadge.style.transform = 'scale(1.5)';
    setTimeout(() => cartBadge.style.transform = 'scale(1)', 200);

    renderCartSidebar();
}

function renderCartSidebar() {
    cartItemsContainer.innerHTML = '';

    if (cart.length === 0) {
        cartItemsContainer.innerHTML = `<p style="text-align:center; color: #a0a0a0; margin-top:20px;">Your cart is empty.</p>`;
        checkoutBtn.disabled = true;
        subtotalDisplay.textContent = '₹0';
        gstDisplay.textContent = '₹0';
        totalDisplay.textContent = '₹0';
        return;
    }

    checkoutBtn.disabled = false;

    cart.forEach(item => {
        const div = document.createElement('div');
        div.className = 'cart-item';
        div.innerHTML = `
            <img src="${item.image}" alt="${item.name}">
            <div class="cart-item-details">
                <div class="cart-item-title">${item.name}</div>
                <div class="cart-item-price">₹${item.price}</div>
                <div class="cart-item-actions">
                    ${getQtyControlsHtml(item.id, item.quantity)}
                    <button class="remove-btn" data-id="${item.id}">Remove</button>
                </div>
            </div>
        `;
        cartItemsContainer.appendChild(div);
    });

    const totals = calculateTotals();
    subtotalDisplay.textContent = `₹${totals.subtotal}`;
    gstDisplay.textContent = `₹${totals.gst}`;
    totalDisplay.textContent = `₹${totals.total}`;
}

function calculateTotals() {
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const gst = Math.round(subtotal * GST_RATE);
    const total = subtotal + gst + DELIVERY_FEE;
    return { subtotal, gst, total };
}

/* --- Checkout & Utilities --- */
async function processPayment() {
    if (!selectedAddressId) {
        alert("Please select a delivery address.");
        return;
    }
    
    paymentModal.classList.remove('active');
    
    const totals = calculateTotals();
    const activeTab = document.querySelector('.pay-tab.active');
    const paymentMethod = activeTab ? activeTab.dataset.method : 'card';
    
    try {
        // Insert order
        const orderId = await window.dbHelper.insertOrder(
            currentUserId, selectedAddressId,
            totals.subtotal, totals.gst, DELIVERY_FEE, totals.total, paymentMethod
        );
        
        // Insert order items
        const orderItemsArray = cart.map(item => ({
            menu_item_id: item.id,
            quantity: item.quantity,
            price_at_order: item.price
        }));
        await window.dbHelper.insertOrderItems(orderId, orderItemsArray);
        
        // Clear cart
        await window.dbHelper.clearCart(currentUserId);
        
        // Insert mock delivery info
        await window.dbHelper.insertDeliveryInfo(
            orderId, 'Raj Kumar', '9876543210', 'MH 12 AB 1234', 'Preparing', 18.5204, 73.8567
        );
        
        orderIdDisplay.textContent = orderId;
        successModal.classList.add('active');
        
    } catch(e) {
        console.error(e);
        alert("Order processing failed.");
    }
}

async function renderAddresses() {
    const addressList = document.getElementById('addressList');
    addressList.innerHTML = '';
    selectedAddressId = null;
    
    if (!currentUserId) return;
    try {
        const addresses = await window.dbHelper.getUserAddresses(currentUserId);
        if (addresses.length === 0) {
            addressList.innerHTML = `<p style="color:#aaa;">No saved addresses found.</p>`;
            return;
        }
        
        addresses.forEach((addr, i) => {
            if (i === 0) selectedAddressId = addr.address_id; // auto select first
            const div = document.createElement('div');
            div.innerHTML = `
                <label style="display: flex; gap: 10px; align-items:flex-start; cursor:pointer;">
                    <input type="radio" name="checkoutAddress" value="${addr.address_id}" ${i === 0 ? 'checked' : ''} style="margin-top:4px;">
                    <div>
                        <strong style="color:var(--accent-orange);">${addr.label}</strong><br>
                        <span style="font-size:0.9rem; color:#ddd;">${addr.full_address}, ${addr.city}, ${addr.state} - ${addr.pincode}</span>
                    </div>
                </label>
            `;
            addressList.appendChild(div);
        });
    } catch(e) { console.error(e); }
}

async function renderOrders() {
    const ordersList = document.getElementById('ordersList');
    if (!ordersList) return;
    ordersList.innerHTML = '';
    const section = document.getElementById('orders');
    
    if (!currentUserId) {
        section.style.display = 'none';
        return;
    }
    
    try {
        const orders = await window.dbHelper.getOrdersByUser(currentUserId);
        if (orders.length === 0) {
            ordersList.innerHTML = `<p style="color:#aaa; text-align:center;">You haven't placed any orders yet.</p>`;
            section.style.display = 'block';
            return;
        }
        
        orders.forEach(order => {
            const formattedDate = new Date(order.created_at).toLocaleString();
            const div = document.createElement('div');
            div.style.cssText = 'background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 10px; padding: 15px; margin-bottom: 10px;';
            div.innerHTML = `
                <div style="display:flex; justify-content:space-between; margin-bottom: 10px; flex-wrap:wrap; gap:10px;">
                    <h3 style="color:var(--text-main); margin:0;">Order #${order.order_id}</h3>
                    <span style="background:var(--accent-orange); color:#fff; padding:3px 10px; border-radius:15px; font-size:0.8rem;">${order.status}</span>
                </div>
                <div style="font-size:0.9rem; color:#aaa; margin-bottom: 10px;">
                    <div>Placed on: ${formattedDate}</div>
                    <div>Total: ₹${order.total_amount} | Payment: ${order.payment_status} (${order.payment_method})</div>
                </div>
            `;
            ordersList.appendChild(div);
        });
        section.style.display = 'block';
    } catch(e) { console.error(e); }
}

function showToast(msg) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `<i class='bx bx-check-circle' style="color: var(--accent-green); font-size:1.2rem;"></i> ${msg}`;
    
    toastContainer.appendChild(toast);

    setTimeout(() => {
        toast.style.animation = 'toastOut 0.3s forwards';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Global animation for toast exit
const style = document.createElement('style');
style.innerHTML = `
@keyframes toastOut {
    from { opacity: 1; transform: translateX(0); }
    to { opacity: 0; transform: translateX(-100%); }
}
`;
document.head.appendChild(style);
