import urllib.request
import re

with open('data.js', 'r', encoding='utf-8') as f:
    code = f.read()

urls = re.findall(r'"(https://images\.unsplash\.com/[^"]+)"', code)
broken = []
for url in urls:
    try:
        req = urllib.request.Request(url, method='HEAD')
        urllib.request.urlopen(req)
    except Exception as e:
        broken.append(url)

print("Total URLs:", len(urls))
print("Broken count:", len(broken))
for b in broken:
    print(b)
