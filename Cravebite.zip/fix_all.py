import urllib.request
import re

with open('data.js', 'r', encoding='utf-8') as f:
    lines = f.readlines()

new_lines = []
broken_count = 0

for line in lines:
    new_line = line
    match_img = re.search(r'image:\s*"(https://images\.unsplash\.com/[^"]+)"', line)
    match_name = re.search(r'name:\s*"([^"]+)"', line)
    
    if match_img and match_name:
        url = match_img.group(1)
        name = match_name.group(1)
        
        # Ping the URL
        is_broken = False
        try:
            req = urllib.request.Request(url, method='HEAD')
            urllib.request.urlopen(req)
        except Exception:
            is_broken = True
            
        if is_broken:
            broken_count += 1
            # Replace with a nicely styled placehold.co image matching the UI
            encoded_name = urllib.parse.quote(name)
            placeholder = f"https://placehold.co/800x600/ff7e00/ffffff.png?text={encoded_name}"
            new_line = line.replace(url, placeholder)
            print(f"Fixed: {name}")
            
    new_lines.append(new_line)

# Save data.js
with open('data.js', 'w', encoding='utf-8') as f:
    f.writelines(new_lines)

print(f"Done! Replaced {broken_count} broken images.")
